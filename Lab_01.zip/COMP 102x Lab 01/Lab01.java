
public class Lab01
{
   public static void main(String[] args) {
       
       // Please code in the following area
       // ---------------------------------

 
     


       // ---------------------------------
   }
}
