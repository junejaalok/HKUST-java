import comp102x.IO;

public class Lab02
{
    
    public static void multiply()
    {
        // Please write your code after this line
        
        
        
        
        
    }
    
    public static void calculateTriangleArea()
    {
        // Please write your code after this line
        
        
        
        
        
    }
    
    public static void solveQuadraticEquation()
    {
        // Please write your code after this line
        
        
        
        
        
    }
}
