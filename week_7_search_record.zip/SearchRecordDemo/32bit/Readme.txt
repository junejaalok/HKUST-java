The dll libraries:

liblept168.dll
libtesseract302.dll

are protected by the Apache License 2.0.

---------------------------------------

